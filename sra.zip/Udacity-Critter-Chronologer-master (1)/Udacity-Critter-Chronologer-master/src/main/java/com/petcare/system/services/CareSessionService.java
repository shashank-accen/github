package com.petcare.system.services;

import com.petcare.system.domain.CareSession;
import com.petcare.system.repositories.CareSessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CareSessionService {
    @Autowired
    private CareSessionRepository careSessionRepository;

    public CareSession save(CareSession careSession) {
        return careSessionRepository.save(careSession);
    }

    public List<CareSession> findAll() {
        return careSessionRepository.findAll();
    }

    public List<CareSession> findAllByCompanionAnimalId(Long companionAnimalId) {
        return careSessionRepository.findAllByCompanionAnimalsId(companionAnimalId);
    }

    public List<CareSession> findAllByCareProviderId(Long careProviderId) {
        return careSessionRepository.findAllByCareProvidersId(careProviderId);
    }

    public List<CareSession> findAllByGuardianId(Long guardianId) {
        return careSessionRepository.findAllByCompanionAnimalsGuardianId(guardianId);
    }
} 