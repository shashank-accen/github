package com.petcare.system.domain;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "companion_animal")
public class CompanionAnimal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long identifier;
    
    private String givenName;
    
    @Enumerated(EnumType.STRING)
    private Species species;
    
    private LocalDate dateOfBirth;
    
    private String medicalNotes;
    
    @ManyToOne
    @JoinColumn(name = "guardian_id")
    private AnimalGuardian guardian;

    public enum Species {
        DOG, CAT, BIRD, FISH, SNAKE, LIZARD, OTHER
    }

    public Long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Long identifier) {
        this.identifier = identifier;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public Species getSpecies() {
        return species;
    }

    public void setSpecies(Species species) {
        this.species = species;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getMedicalNotes() {
        return medicalNotes;
    }

    public void setMedicalNotes(String medicalNotes) {
        this.medicalNotes = medicalNotes;
    }

    public AnimalGuardian getGuardian() {
        return guardian;
    }

    public void setGuardian(AnimalGuardian guardian) {
        this.guardian = guardian;
    }
} 