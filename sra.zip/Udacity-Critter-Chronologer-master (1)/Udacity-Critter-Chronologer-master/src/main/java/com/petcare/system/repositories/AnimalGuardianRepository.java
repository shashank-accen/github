package com.petcare.system.repositories;

import com.petcare.system.domain.AnimalGuardian;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AnimalGuardianRepository extends JpaRepository<AnimalGuardian, Long> {
} 