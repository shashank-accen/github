package com.petcare.system.services;

import com.petcare.system.domain.AnimalGuardian;
import com.petcare.system.repositories.AnimalGuardianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnimalGuardianService {
    @Autowired
    private AnimalGuardianRepository animalGuardianRepository;

    public AnimalGuardian save(AnimalGuardian animalGuardian) {
        return animalGuardianRepository.save(animalGuardian);
    }

    public List<AnimalGuardian> findAll() {
        return animalGuardianRepository.findAll();
    }
} 