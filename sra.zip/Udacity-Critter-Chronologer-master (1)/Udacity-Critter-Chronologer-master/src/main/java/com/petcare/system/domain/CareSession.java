package com.petcare.system.domain;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "care_session")
public class CareSession {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long identifier;
    
    @ManyToMany
    @JoinTable(
        name = "session_providers",
        joinColumns = @JoinColumn(name = "session_id"),
        inverseJoinColumns = @JoinColumn(name = "provider_id")
    )
    private List<CareProvider> careProviders;
    
    @ManyToMany
    @JoinTable(
        name = "session_animals",
        joinColumns = @JoinColumn(name = "session_id"),
        inverseJoinColumns = @JoinColumn(name = "animal_id")
    )
    private List<CompanionAnimal> companionAnimals;
    
    private LocalDate sessionDate;
    private LocalTime commencementTime;
    private LocalTime conclusionTime;
    
    @ElementCollection
    @CollectionTable(name = "session_services", joinColumns = @JoinColumn(name = "session_id"))
    @Enumerated(EnumType.STRING)
    private Set<ServiceType> providedServices;

    public enum ServiceType {
        GROOMING_SESSION, TRAINING_CLASS, HEALTH_CHECK, EXERCISE_PERIOD, 
        OVERNIGHT_STAY, DAY_CARE
    }

    public Long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Long identifier) {
        this.identifier = identifier;
    }

    public List<CareProvider> getCareProviders() {
        return careProviders;
    }

    public void setCareProviders(List<CareProvider> careProviders) {
        this.careProviders = careProviders;
    }

    public List<CompanionAnimal> getCompanionAnimals() {
        return companionAnimals;
    }

    public void setCompanionAnimals(List<CompanionAnimal> companionAnimals) {
        this.companionAnimals = companionAnimals;
    }

    public LocalDate getSessionDate() {
        return sessionDate;
    }

    public void setSessionDate(LocalDate sessionDate) {
        this.sessionDate = sessionDate;
    }

    public LocalTime getCommencementTime() {
        return commencementTime;
    }

    public void setCommencementTime(LocalTime commencementTime) {
        this.commencementTime = commencementTime;
    }

    public LocalTime getConclusionTime() {
        return conclusionTime;
    }

    public void setConclusionTime(LocalTime conclusionTime) {
        this.conclusionTime = conclusionTime;
    }

    public Set<ServiceType> getProvidedServices() {
        return providedServices;
    }

    public void setProvidedServices(Set<ServiceType> providedServices) {
        this.providedServices = providedServices;
    }
} 