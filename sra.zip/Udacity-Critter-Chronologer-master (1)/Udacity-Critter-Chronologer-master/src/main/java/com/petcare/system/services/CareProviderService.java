package com.petcare.system.services;

import com.petcare.system.domain.CareProvider;
import com.petcare.system.repositories.CareProviderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Set;

@Service
public class CareProviderService {
    @Autowired
    private CareProviderRepository careProviderRepository;

    public CareProvider save(CareProvider careProvider) {
        return careProviderRepository.save(careProvider);
    }

    public List<CareProvider> findAll() {
        return careProviderRepository.findAll();
    }

    public List<CareProvider> findAvailableProviders(DayOfWeek day, Set<CareProvider.Expertise> expertise) {
        return careProviderRepository.findAllByAvailableDaysContainingAndAreasOfExpertiseIn(day, expertise);
    }
} 