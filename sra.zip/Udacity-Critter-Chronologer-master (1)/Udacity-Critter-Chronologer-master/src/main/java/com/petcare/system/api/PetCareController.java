package com.petcare.system.api;

import com.petcare.system.domain.*;
import com.petcare.system.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api")
public class PetCareController {
    @Autowired
    private AnimalGuardianService animalGuardianService;
    @Autowired
    private CompanionAnimalService companionAnimalService;
    @Autowired
    private CareProviderService careProviderService;
    @Autowired
    private CareSessionService careSessionService;

    @PostMapping("/customer")
    public AnimalGuardian saveGuardian(@RequestBody AnimalGuardian animalGuardian) {
        return animalGuardianService.save(animalGuardian);
    }

    @GetMapping("/customer")
    public List<AnimalGuardian> getAllGuardians() {
        return animalGuardianService.findAll();
    }

    @PostMapping("/pet")
    public CompanionAnimal saveCompanion(@RequestBody CompanionAnimal companionAnimal) {
        return companionAnimalService.save(companionAnimal);
    }

    @GetMapping("/pet")
    public List<CompanionAnimal> getAllCompanions() {
        return companionAnimalService.findAll();
    }

    @GetMapping("/pet/customer/{guardianId}")
    public List<CompanionAnimal> getCompanionsByGuardian(@PathVariable Long guardianId) {
        return companionAnimalService.findAllByGuardianId(guardianId);
    }

    @PostMapping("/employee")
    public CareProvider saveProvider(@RequestBody CareProvider careProvider) {
        return careProviderService.save(careProvider);
    }

    @PutMapping("/employee/{providerId}/availability")
    public CareProvider updateProviderAvailability(@PathVariable Long providerId, @RequestBody Set<DayOfWeek> availableDays) {
        CareProvider careProvider = careProviderService.findAll().stream()
            .filter(p -> p.getIdentifier().equals(providerId))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Provider not found"));
        careProvider.setAvailableDays(availableDays);
        return careProviderService.save(careProvider);
    }

    @GetMapping("/employee/availability")
    public List<CareProvider> getAvailableProviders(@RequestParam String date, @RequestBody Set<CareProvider.Expertise> expertise) {
        DayOfWeek day = DayOfWeek.valueOf(date.toUpperCase());
        return careProviderService.findAvailableProviders(day, expertise);
    }

    @PostMapping("/schedule")
    public CareSession createSession(@RequestBody CareSession careSession) {
        return careSessionService.save(careSession);
    }

    @GetMapping("/schedule/pet/{companionId}")
    public List<CareSession> getSessionsByCompanion(@PathVariable Long companionId) {
        return careSessionService.findAllByCompanionAnimalId(companionId);
    }

    @GetMapping("/schedule/employee/{providerId}")
    public List<CareSession> getSessionsByProvider(@PathVariable Long providerId) {
        return careSessionService.findAllByCareProviderId(providerId);
    }

    @GetMapping("/schedule/customer/{guardianId}")
    public List<CareSession> getSessionsByGuardian(@PathVariable Long guardianId) {
        return careSessionService.findAllByGuardianId(guardianId);
    }
} 