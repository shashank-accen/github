package com.petcare.system.repositories;

import com.petcare.system.domain.CareSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CareSessionRepository extends JpaRepository<CareSession, Long> {
    List<CareSession> findAllByCompanionAnimalsId(Long companionAnimalId);
    List<CareSession> findAllByCareProvidersId(Long careProviderId);
    List<CareSession> findAllByCompanionAnimalsGuardianId(Long guardianId);
} 