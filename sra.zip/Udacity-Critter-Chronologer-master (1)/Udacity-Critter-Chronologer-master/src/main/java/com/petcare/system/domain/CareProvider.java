package com.petcare.system.domain;

import javax.persistence.*;
import java.time.DayOfWeek;
import java.util.Set;

@Entity
@Table(name = "care_provider")
public class CareProvider {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long identifier;
    
    private String primaryName;
    private String familyName;
    private String contactNumber;
    private String electronicMail;
    
    @ElementCollection
    @CollectionTable(name = "provider_expertise", joinColumns = @JoinColumn(name = "provider_id"))
    @Enumerated(EnumType.STRING)
    private Set<Expertise> areasOfExpertise;
    
    @ElementCollection
    @CollectionTable(name = "provider_availability", joinColumns = @JoinColumn(name = "provider_id"))
    @Enumerated(EnumType.STRING)
    private Set<DayOfWeek> availableDays;

    public enum Expertise {
        FEEDING, PETTING, WALKING, GROOMING, SHAVING, MEDICATING
    }

    public Long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Long identifier) {
        this.identifier = identifier;
    }

    public String getPrimaryName() {
        return primaryName;
    }

    public void setPrimaryName(String primaryName) {
        this.primaryName = primaryName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getElectronicMail() {
        return electronicMail;
    }

    public void setElectronicMail(String electronicMail) {
        this.electronicMail = electronicMail;
    }

    public Set<Expertise> getAreasOfExpertise() {
        return areasOfExpertise;
    }

    public void setAreasOfExpertise(Set<Expertise> areasOfExpertise) {
        this.areasOfExpertise = areasOfExpertise;
    }

    public Set<DayOfWeek> getAvailableDays() {
        return availableDays;
    }

    public void setAvailableDays(Set<DayOfWeek> availableDays) {
        this.availableDays = availableDays;
    }
} 