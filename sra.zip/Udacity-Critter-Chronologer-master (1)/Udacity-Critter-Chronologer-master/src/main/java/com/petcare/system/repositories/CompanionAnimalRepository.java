package com.petcare.system.repositories;

import com.petcare.system.domain.CompanionAnimal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CompanionAnimalRepository extends JpaRepository<CompanionAnimal, Long> {
    List<CompanionAnimal> findAllByGuardianId(Long guardianId);
} 