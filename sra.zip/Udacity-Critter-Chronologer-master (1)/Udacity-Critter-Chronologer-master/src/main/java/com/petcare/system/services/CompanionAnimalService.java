package com.petcare.system.services;

import com.petcare.system.domain.CompanionAnimal;
import com.petcare.system.repositories.CompanionAnimalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanionAnimalService {
    @Autowired
    private CompanionAnimalRepository companionAnimalRepository;

    public CompanionAnimal save(CompanionAnimal companionAnimal) {
        return companionAnimalRepository.save(companionAnimal);
    }

    public List<CompanionAnimal> findAll() {
        return companionAnimalRepository.findAll();
    }

    public List<CompanionAnimal> findAllByGuardianId(Long guardianId) {
        return companionAnimalRepository.findAllByGuardianId(guardianId);
    }
} 