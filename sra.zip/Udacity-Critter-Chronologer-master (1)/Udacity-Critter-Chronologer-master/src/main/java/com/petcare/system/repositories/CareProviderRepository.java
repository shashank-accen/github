package com.petcare.system.repositories;

import com.petcare.system.domain.CareProvider;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Set;

@Repository
public interface CareProviderRepository extends JpaRepository<CareProvider, Long> {
    List<CareProvider> findAllByAvailableDaysContainingAndAreasOfExpertiseIn(DayOfWeek day, Set<CareProvider.Expertise> expertise);
} 