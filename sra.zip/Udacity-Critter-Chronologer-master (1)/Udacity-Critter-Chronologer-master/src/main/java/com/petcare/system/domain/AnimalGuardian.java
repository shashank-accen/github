package com.petcare.system.domain;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "animal_guardian")
public class AnimalGuardian {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long identifier;
    
    private String primaryName;
    private String familyName;
    private String contactNumber;
    private String electronicMail;
    
    @OneToMany(mappedBy = "guardian", cascade = CascadeType.ALL)
    private List<CompanionAnimal> companionAnimals = new ArrayList<>();

    public Long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Long identifier) {
        this.identifier = identifier;
    }

    public String getPrimaryName() {
        return primaryName;
    }

    public void setPrimaryName(String primaryName) {
        this.primaryName = primaryName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getElectronicMail() {
        return electronicMail;
    }

    public void setElectronicMail(String electronicMail) {
        this.electronicMail = electronicMail;
    }

    public List<CompanionAnimal> getCompanionAnimals() {
        return companionAnimals;
    }

    public void setCompanionAnimals(List<CompanionAnimal> companionAnimals) {
        this.companionAnimals = companionAnimals;
    }
} 