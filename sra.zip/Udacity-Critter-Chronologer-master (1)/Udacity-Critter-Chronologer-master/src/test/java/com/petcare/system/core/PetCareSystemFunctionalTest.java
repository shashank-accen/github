package com.petcare.system.core;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.petcare.system.api.PetCareController;
import com.petcare.system.domain.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@SpringBootTest(classes = PetCareSystemApplication.class)
@Transactional
@ActiveProfiles("test")
public class PetCareSystemFunctionalTest {

    @Autowired
    private PetCareController petCareController;

    private static CareProvider generateEmployee() {
        CareProvider emp = new CareProvider();
        emp.setPrimaryName("EmployeeTest");
        emp.setAreasOfExpertise(Sets.newHashSet(CareProvider.Expertise.FEEDING, CareProvider.Expertise.PETTING));
        return emp;
    }

    private static AnimalGuardian generateCustomer() {
        AnimalGuardian customer = new AnimalGuardian();
        customer.setPrimaryName("CustomerTest");
        customer.setContactNumber("1234567890");
        return customer;
    }

    private static CompanionAnimal generatePet() {
        CompanionAnimal pet = new CompanionAnimal();
        pet.setGivenName("PetTest");
        pet.setSpecies(CompanionAnimal.Species.DOG);
        return pet;
    }

    private static CareSession buildSchedule(List<Long> pets, List<Long> employees, LocalDate date, Set<CareProvider.Expertise> activities) {
        CareSession schedule = new CareSession();
        schedule.setCompanionAnimals(pets.stream().map(id -> {
            CompanionAnimal pet = new CompanionAnimal();
            pet.setIdentifier(id);
            return pet;
        }).collect(Collectors.toList()));
        schedule.setCareProviders(employees.stream().map(id -> {
            CareProvider provider = new CareProvider();
            provider.setIdentifier(id);
            return provider;
        }).collect(Collectors.toList()));
        schedule.setSessionDate(date);
        schedule.setProvidedServices(activities.stream()
            .map(expertise -> CareSession.ServiceType.valueOf(expertise.name()))
            .collect(Collectors.toSet()));
        return schedule;
    }

    private static void verifySchedules(CareSession expected, CareSession actual) {
        Assertions.assertEquals(expected.getProvidedServices(), actual.getProvidedServices());
        Assertions.assertEquals(expected.getSessionDate(), actual.getSessionDate());
        Assertions.assertEquals(
            expected.getCareProviders().stream().map(CareProvider::getIdentifier).collect(Collectors.toList()),
            actual.getCareProviders().stream().map(CareProvider::getIdentifier).collect(Collectors.toList())
        );
        Assertions.assertEquals(
            expected.getCompanionAnimals().stream().map(CompanionAnimal::getIdentifier).collect(Collectors.toList()),
            actual.getCompanionAnimals().stream().map(CompanionAnimal::getIdentifier).collect(Collectors.toList())
        );
    }

    @Test
    public void createCustomerTest() {
        AnimalGuardian inputCustomer = generateCustomer();
        AnimalGuardian savedCustomer = petCareController.saveGuardian(inputCustomer);
        List<AnimalGuardian> allCustomers = petCareController.getAllGuardians();
        AnimalGuardian fetchedCustomer = allCustomers.get(0);

        Assertions.assertEquals(inputCustomer.getPrimaryName(), savedCustomer.getPrimaryName());
        Assertions.assertEquals(fetchedCustomer.getIdentifier(), savedCustomer.getIdentifier());
        Assertions.assertTrue(fetchedCustomer.getIdentifier() > 0);
    }

    @Test
    public void createEmployeeTest() {
        CareProvider inputEmployee = generateEmployee();
        CareProvider savedEmployee = petCareController.saveProvider(inputEmployee);
        List<CareProvider> availableEmployees = petCareController.getAvailableProviders("MONDAY", Sets.newHashSet(CareProvider.Expertise.FEEDING));
        CareProvider retrievedEmployee = availableEmployees.get(0);

        Assertions.assertEquals(inputEmployee.getAreasOfExpertise(), savedEmployee.getAreasOfExpertise());
        Assertions.assertEquals(savedEmployee.getIdentifier(), retrievedEmployee.getIdentifier());
    }

    @Test
    public void assignPetsToCustomerTest() {
        AnimalGuardian customer = petCareController.saveGuardian(generateCustomer());
        CompanionAnimal pet = generatePet();
        pet.setGuardian(customer);
        CompanionAnimal storedPet = petCareController.saveCompanion(pet);

        List<CompanionAnimal> allPets = petCareController.getAllCompanions();
        CompanionAnimal retrievedPet = allPets.get(0);
        Assertions.assertEquals(retrievedPet.getGuardian().getIdentifier(), customer.getIdentifier());

        List<CompanionAnimal> customerPets = petCareController.getCompanionsByGuardian(customer.getIdentifier());
        Assertions.assertEquals(customerPets.get(0).getIdentifier(), storedPet.getIdentifier());

        List<AnimalGuardian> allCustomers = petCareController.getAllGuardians();
        AnimalGuardian updatedCustomer = allCustomers.get(0);
        Assertions.assertTrue(updatedCustomer.getCompanionAnimals() != null && !updatedCustomer.getCompanionAnimals().isEmpty());
        Assertions.assertEquals(updatedCustomer.getCompanionAnimals().get(0).getIdentifier(), storedPet.getIdentifier());
    }

    @Test
    public void findPetsByOwnerTest() {
        AnimalGuardian customer = petCareController.saveGuardian(generateCustomer());

        CompanionAnimal pet1 = generatePet();
        pet1.setGuardian(customer);
        CompanionAnimal storedPet1 = petCareController.saveCompanion(pet1);

        CompanionAnimal pet2 = generatePet();
        pet2.setGuardian(customer);
        pet2.setGivenName("AnotherPet");
        pet2.setSpecies(CompanionAnimal.Species.CAT);
        CompanionAnimal storedPet2 = petCareController.saveCompanion(pet2);

        List<CompanionAnimal> pets = petCareController.getCompanionsByGuardian(customer.getIdentifier());
        Assertions.assertEquals(2, pets.size());
    }

    @Test
    public void changeEmployeeAvailabilityTest() {
        CareProvider employee = generateEmployee();
        CareProvider storedEmployee = petCareController.saveProvider(employee);

        Set<DayOfWeek> availableDays = Sets.newHashSet(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY);
        petCareController.updateProviderAvailability(storedEmployee.getIdentifier(), availableDays);

        List<CareProvider> availableEmployees = petCareController.getAvailableProviders("MONDAY", Sets.newHashSet(CareProvider.Expertise.FEEDING));
        CareProvider updatedEmployee = availableEmployees.get(0);
        Assertions.assertEquals(availableDays, updatedEmployee.getAvailableDays());
    }

    @Test
    public void scheduleServiceTest() {
        CareProvider emp = generateEmployee();
        emp.setAvailableDays(Sets.newHashSet(DayOfWeek.WEDNESDAY));
        CareProvider savedEmp = petCareController.saveProvider(emp);

        AnimalGuardian customer = petCareController.saveGuardian(generateCustomer());

        CompanionAnimal pet = generatePet();
        pet.setGuardian(customer);
        CompanionAnimal savedPet = petCareController.saveCompanion(pet);

        LocalDate date = LocalDate.of(2019, 12, 25);
        List<Long> petIds = Lists.newArrayList(savedPet.getIdentifier());
        List<Long> empIds = Lists.newArrayList(savedEmp.getIdentifier());
        Set<CareProvider.Expertise> skills = Sets.newHashSet(CareProvider.Expertise.PETTING);

        CareSession createdSchedule = petCareController.createSession(buildSchedule(petIds, empIds, date, skills));
        List<CareSession> petSchedules = petCareController.getSessionsByCompanion(savedPet.getIdentifier());
        CareSession retrievedSchedule = petSchedules.get(0);

        Assertions.assertEquals(date, retrievedSchedule.getSessionDate());
        Assertions.assertEquals(
            empIds,
            retrievedSchedule.getCareProviders().stream().map(CareProvider::getIdentifier).collect(Collectors.toList())
        );
        Assertions.assertEquals(
            petIds,
            retrievedSchedule.getCompanionAnimals().stream().map(CompanionAnimal::getIdentifier).collect(Collectors.toList())
        );
        Assertions.assertEquals(
            skills.stream()
                .map(expertise -> CareSession.ServiceType.valueOf(expertise.name()))
                .collect(Collectors.toSet()),
            retrievedSchedule.getProvidedServices()
        );
    }
} 